// Calls the EquiHealth RAG backend. No secrets here: the Gemini key lives on the server only.
const API_URL = process.env.EXPO_PUBLIC_API_URL; // e.g. http://192.168.1.23:8000

export async function askQuestion(question, conditions = null) {
  const res = await fetch(`${API_URL}/ask`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ question, conditions }),
  });
  if (!res.ok) throw new Error(`Ask failed: ${res.status}`);
  return res.json(); // { answer, sources }
}
